const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const app = express();
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.ALLOWED_ORIGIN ? process.env.ALLOWED_ORIGIN.split(',').map(s => s.trim()) : true }));
app.use(express.json({ limit: '16kb' }));
app.use(rateLimit({ windowMs: 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false }));

const PORT = process.env.PORT || 8080;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-5.6-luna';
const REQUEST_TIMEOUT_MS = 10000;
const LIMITS = { General:[0,200], 'Red Dot':[0,200], '2X Scope':[0,200], '4X Scope':[0,200], 'Sniper Scope':[0,100], 'Free Look':[0,200], 'Fire Button Size':[30,70], DPI:[300,700] };
function clean(v, max=80){return String(v ?? '').trim().slice(0,max)}
function clampResult(x){const out={};for(const [k,[lo,hi]] of Object.entries(LIMITS)){const n=Math.round(Number(x?.[k]));if(!Number.isFinite(n))throw new Error('invalid ai result');out[k]=Math.max(lo,Math.min(hi,n));}return out}
function fallback(input){let base=105;if(input.device==='iPhone')base+=4;if(input.device==='PC')base-=5;if(/^(2|3) GB/.test(input.ram))base-=7;if(/^(12|16)/.test(input.ram))base+=4;if(input.gyro==='High')base+=5;if(input.playStyle==='Rush')base+=7;if(input.playStyle==='Headshot')base+=4;if(input.playStyle==='Sniper')base-=8;if(input.control==='Short')base+=5;if(input.control==='Long')base-=2;if(input.control==='Hacker')base+=8;base=Math.max(70,Math.min(190,base));return clampResult({General:base,'Red Dot':base-5,'2X Scope':base+3,'4X Scope':base-2,'Sniper Scope':input.playStyle==='Sniper'?62:48,'Free Look':base-35,'Fire Button Size':input.control==='Short'?58:input.control==='Hacker'?62:52,DPI:input.device==='iPhone'?390:input.playStyle==='Rush'?480:450})}
app.get('/health',(_req,res)=>res.json({ok:true,service:'Venom_Squad AI'}));
app.post('/v1/sensitivity',async(req,res)=>{
  const b=req.body||{};const input={device:clean(b.device),brand:clean(b.brand),model:clean(b.model),ram:clean(b.ram),gyro:clean(b.gyro),playStyle:clean(b.playStyle),control:clean(b.control)};
  if(!['Android','iPhone','PC'].includes(input.device)||!['Low','High'].includes(input.gyro)||!['Rush','Push','Headshot','Sniper'].includes(input.playStyle)||!['Long','Short','Hacker'].includes(input.control))return res.status(400).json({error:'Invalid input.'});
  if(!OPENAI_API_KEY)return res.json({source:'offline-backend',settings:fallback(input)});
  const prompt=`You are Venom_Squad's sensitivity recommendation engine for Free Fire MAX. Return ONLY JSON with exactly these integer fields: General 0-200, Red Dot 0-200, 2X Scope 0-200, 4X Scope 0-200, Sniper Scope 0-100, Free Look 0-200, Fire Button Size 30-70, DPI 300-700. User: ${JSON.stringify(input)}. Give a practical starting point. Do not claim guaranteed headshots, cheats, exploits, automation, or game modification.`;
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),REQUEST_TIMEOUT_MS);
  try{const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${OPENAI_API_KEY}`},body:JSON.stringify({model:OPENAI_MODEL,input:prompt}),signal:controller.signal});const data=await r.json();if(!r.ok)throw new Error('provider');const text=data.output_text||(data.output||[]).flatMap(x=>x.content||[]).map(x=>x.text||'').join('');const match=String(text).match(/\{[\s\S]*\}/);if(!match)throw new Error('invalid');return res.json({source:'online-ai',settings:clampResult(JSON.parse(match[0]))});}
  catch(_e){return res.json({source:'offline-backend',settings:fallback(input)});}finally{clearTimeout(timer)}
});
app.listen(PORT,()=>console.log(`Venom_Squad backend listening on ${PORT}`));
