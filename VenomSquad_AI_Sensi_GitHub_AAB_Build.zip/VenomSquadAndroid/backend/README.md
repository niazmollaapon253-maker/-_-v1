# Venom_Squad Online AI backend

This service keeps the AI provider secret off the Android app. Deploy it on a server with HTTPS.

## Setup
1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put the provider API key in the server environment only.
5. Start with `node server.js`.
6. Set the Android `app/src/main/assets/config.js` `AI_ENDPOINT` to your HTTPS `/v1/sensitivity` URL.

The endpoint validates inputs, rate-limits requests, uses HTTPS for the provider call, and falls back to a local rules engine if the provider is unavailable.

Do not commit `.env` or any secret key. For production, add authentication/abuse controls appropriate to your hosting setup and publish a privacy policy matching actual data handling.
