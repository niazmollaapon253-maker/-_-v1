# Data Safety — draft, verify before submission

The final answers must match the actual deployed backend and privacy policy.

Current project behavior:
- No advertising SDK.
- No account/sign-in system in the Android client.
- User-entered device/play-profile inputs can be sent to the Venom_Squad backend only when an HTTPS AI endpoint is configured.
- No provider API secret is stored in the Android app.
- LocalStorage is used for the last generated result on the device.

Before production, the developer must decide and document backend retention, logging, analytics, crash reporting, and deletion practices, then answer Play Console Data Safety questions accordingly.
