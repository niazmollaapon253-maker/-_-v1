# Google Play Store Listing — Venom_Squad AI Sensi

## App name
Venom_Squad AI Sensi

## Short description
AI-powered sensitivity recommendations for Free Fire MAX players.

## Full description
Venom_Squad AI Sensi helps Free Fire MAX players create a personalized sensitivity starting point from their device and play preferences.

Features:
- Device, brand and model based profile
- RAM selection
- Gyroscope preference
- Rush, Push, Headshot and Sniper play styles
- Long, Short and Hacker control preferences
- Recommended General, Red Dot, 2x, 4x, Sniper and Free Look sensitivity
- Fire Button Size and DPI recommendations
- Copy settings and remember the last result
- Purple/black AI-themed interface
- No advertising SDKs

Venom_Squad does not modify Free Fire MAX, inject code, or guarantee headshots or performance. Recommendations are starting points and may need adjustment for each player.

Free Fire MAX is a trademark of Garena. Venom_Squad is an independent utility and is not affiliated with or endorsed by Garena.
