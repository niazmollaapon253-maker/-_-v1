# Venom_Squad publish status

READY:
- Android project structure
- Target SDK 36
- Application ID com.venomsquad.aisensi
- App icon/logo
- No ad SDK
- HTTPS-only networking flag
- Online AI endpoint configuration slot
- Offline fallback
- Play Store listing draft
- Data Safety draft
- Privacy policy template

STILL REQUIRES DEVELOPER ACTION:
1. Deploy the backend on a real HTTPS domain.
2. Put the production backend URL in app/src/main/assets/config.js.
3. Replace the privacy-policy template with a public policy matching actual data practices.
4. Build a signed release AAB using a secure signing key.
5. Create/verify the Google Play Console developer account.
6. Complete Play Console testing and declarations required for the account.
7. Upload the AAB and submit it for review.

This package does not contain a fabricated AAB or fake online-AI connection.
