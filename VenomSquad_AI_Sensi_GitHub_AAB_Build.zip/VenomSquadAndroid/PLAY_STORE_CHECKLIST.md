# Venom_Squad Play Store checklist

- [x] Package: com.venomsquad.aisensi
- [x] Target SDK 36 / Android 16
- [x] No ads SDK
- [x] HTTPS-only app traffic
- [x] Online AI secret kept on backend, not APK
- [x] App icon and logo included
- [x] Privacy/About UI included
- [x] Privacy policy template included
- [ ] Deploy backend over HTTPS and set AI_ENDPOINT
- [ ] Publish the final privacy policy at a public HTTPS URL
- [ ] Complete Google Play Data Safety form to match actual implementation
- [ ] Create signed release AAB with your own upload key
- [ ] Complete Play Console developer verification/package registration requirements applicable to your account
- [ ] Complete required testing/review steps in Play Console
- [ ] Add store listing: title, short description, full description, screenshots, icon, category, contact email
- [ ] Test on multiple Android devices and verify Online AI + offline fallback
