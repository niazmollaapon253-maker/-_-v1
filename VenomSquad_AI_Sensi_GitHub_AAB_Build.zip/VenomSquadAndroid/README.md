# Venom_Squad AI Sensi — Android project

Version 1.2.0. Package: `com.venomsquad.aisensi`.

## Included
- Purple/black AI-themed UI with Venom_Squad logo
- No advertising SDK
- Android device manufacturer/model bridge
- Brand-based RAM choices
- Gyroscope, play style and control profile inputs
- Online AI endpoint configuration with offline fallback
- Result cards, progress bars, copy settings and last-result storage
- Privacy/About screens
- HTTPS-only app networking (`usesCleartextTraffic=false`)
- Backend template with rate limiting and secret-key separation
- Play Store checklist and privacy-policy template

## Build
Open the project in a recent Android Studio, install Android SDK 36, sync Gradle, then build a signed Android App Bundle (AAB).

The container used to prepare this project does not include a working Android Gradle build environment, so no AAB is fabricated here. The source is prepared for Android/Play Store build workflow.

## Online AI
Edit `app/src/main/assets/config.js` and set `AI_ENDPOINT` to your deployed HTTPS backend endpoint. Never put a private provider API key in the APK.

## Play Store
As of August 31, 2026, new Google Play apps and updates must target Android 16/API 36 or higher. This project targets API 36. Google Play also requires the appropriate store declarations, testing, signing, privacy policy and other review requirements before publication.

## Build without Android Studio
See `GITHUB_ACTIONS_AAB.md`. GitHub Actions workflows are included under `.github/workflows/` for cloud AAB builds.
