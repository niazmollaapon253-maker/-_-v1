plugins { id("com.android.application") }

android {
    namespace = "com.venomsquad.aisensi"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.venomsquad.aisensi"
        minSdk = 23
        targetSdk = 36
        versionCode = 3
        versionName = "1.2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}
