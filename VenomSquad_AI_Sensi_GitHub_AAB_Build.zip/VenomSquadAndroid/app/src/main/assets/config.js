// Production: set your deployed HTTPS endpoint here, for example:
// const AI_ENDPOINT = 'https://api.yourdomain.com/v1/sensitivity';
// Never put an OpenAI/AI provider secret key in this file or in the APK.
const AI_ENDPOINT = '';
