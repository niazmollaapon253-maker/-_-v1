# GitHub Actions AAB Build

This project now includes automatic cloud builds. No Android Studio is required on your PC for the GitHub Actions build.

## Unsigned AAB
1. Upload the contents of this project to a GitHub repository.
2. Open **Actions** and run **Build Venom_Squad AAB** (or push to `main`).
3. Open the completed workflow run.
4. Under **Artifacts**, download `Venom_Squad-release-aab`.

The unsigned AAB is useful for build/testing, but Google Play production releases require a properly signed bundle.

## Signed AAB
The repository also includes **Build signed Venom_Squad AAB**. Before running it, create these GitHub Actions repository secrets:

- `ANDROID_KEYSTORE_BASE64`: base64-encoded release keystore
- `ANDROID_KEYSTORE_PASSWORD`: keystore password
- `ANDROID_KEY_ALIAS`: key alias
- `ANDROID_KEY_PASSWORD`: key password

Keep the keystore and all passwords private. Never commit them to the repository.

After the signed workflow completes, download the `Venom_Squad-signed-release-aab` artifact.
