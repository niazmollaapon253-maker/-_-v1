# Privacy Policy — Venom_Squad

**Last updated:** [DATE]

**Developer:** [LEGAL DEVELOPER / COMPANY NAME]
**Contact:** [PRIVACY EMAIL]

Venom_Squad is a sensitivity recommendation app for Free Fire MAX. It is not affiliated with or endorsed by Garena.

## Information used
The app may use information you enter or select, including device type, brand, model, RAM selection, gyroscope preference, play style and control preference, to generate sensitivity recommendations.

If Online AI is enabled, these selected inputs are sent to the Venom_Squad backend over HTTPS for recommendation generation. The backend may send the request to the configured AI provider.

## Advertising
Venom_Squad does not include advertising SDKs and does not display ads.

## Accounts
The current app does not require a user account.

## Storage
The app may store the most recent recommendation locally on the device so it can be displayed again. [CONFIRM OR EDIT THIS BEFORE PUBLISHING.]

## Sharing and retention
[DESCRIBE EXACTLY WHETHER BACKEND REQUESTS ARE LOGGED, RETAINED, DELETED, OR SHARED. DO NOT PUBLISH THIS TEMPLATE UNCHANGED.]

## Security
Online requests should be sent only over HTTPS. Server-side AI credentials must never be embedded in the Android app.

## Children
The app does not knowingly require children to provide an account or unnecessary personal information. [REVIEW THIS SECTION WITH YOUR ACTUAL TARGET-AUDIENCE SETTINGS BEFORE PUBLISHING.]

## Changes
We may update this policy when the app's data practices change. The latest version will be published at [PUBLIC HTTPS PRIVACY POLICY URL].

## Contact
For privacy questions, contact [PRIVACY EMAIL].
